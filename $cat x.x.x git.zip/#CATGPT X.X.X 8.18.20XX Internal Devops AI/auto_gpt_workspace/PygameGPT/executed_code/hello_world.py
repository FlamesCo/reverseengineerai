import pygame

# Initialize Pygame
pygame.init()

# Set the window size
window_width = 800
window_height = 600
window_size = (window_width, window_height)

# Create the window
window = pygame.display.set_mode(window_size)

# Set the window title
pygame.display.set_caption('Hello World')

# Set the font
font = pygame.font.Font(None, 36)

# Set the text
text = font.render('Hello World', True, (255, 255, 255))

# Get the text size
text_width, text_height = text.get_size()

# Calculate the position to center the text
text_x = (window_width - text_width) // 2
text_y = (window_height - text_height) // 2

# Main game loop
running = True
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Clear the window
    window.fill((0, 0, 0))

    # Draw the text
    window.blit(text, (text_x, text_y))

    # Update the display
    pygame.display.update()

# Quit Pygame
pygame.quit()